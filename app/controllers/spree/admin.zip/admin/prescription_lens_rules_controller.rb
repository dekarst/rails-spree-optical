module Spree
    module Admin
        class PrescriptionLensRulesController < ResourceController
            def model_class
                PrescriptionLensRule
            end
        end
    end
end
